# MEA speciation parameter regression

This fixed campaign fits three shared ePC-SAFT parameters to 131 admitted
speciation measurements at 44 homogeneous MEA states. It uses the installed
Engine wheel, public GREPE and Regression APIs, and one simultaneous sparse
full-space IPOPT solve. The campaign has no runtime options or dependency on a
second repository.

```bash
.venv/bin/python validation/campaigns/2026-mea-grepe-regression/scripts/run_campaign.py
```

The script writes the exact fit request, complete FitResult, fitted Parameters,
and a compact summary under `results/`. The parameter and observation inputs
are immutable local files under `source/`.

The completed installed-wheel campaign evaluated all 131 targets without a
drop or rejection using the simultaneous sparse full-space backend. It fitted
`k_ij = 0.10159970424983134`, `sigma_MEAH+ = 4.365905218305267 angstrom`, and
`sigma_MEACOO- = 5.1809945813168845 angstrom` with objective
`0.0343599102370016` in 26 IPOPT iterations and 95.89 seconds.

## CO2 partial-pressure validation

The independent pressure check uses 58 source-backed 30 wt% MEA observations
from Hilliard (2008) and Jou et al. (1995) at 40, 60, and 80 °C:

```bash
.venv/bin/python validation/campaigns/2026-mea-grepe-regression/scripts/run_pressure_validation.py
.venv/bin/python validation/campaigns/2026-mea-grepe-regression/scripts/plot_pressure_validation.py
```

Each in-domain row is a fixed-pressure, single-finite-phase public GREPE
request. The predicted liquid CO2 fugacity is compared with the measured CO2
partial pressure; the specialized reactive-bubble calling route is not used. The
four-process replay took 29.77 seconds and evaluated 55 rows with zero solver
or certificate failures. Three Jou rows at 500, 600, and 1000 kPa remain in
the table as `outside_parameter_domain` because the fitted parameter document
declares a 300 kPa upper pressure bound.

The pressure result is a failed predictive check, not another fit: median
absolute `log10(model / observed)` is 1.024 and the maximum is 1.211. The
revised speciation-fitted set therefore overpredicts pressure by roughly one
order of magnitude and must not be described as pressure-validated.

Hilliard and Jou are observation sources, not separate models. The plot uses
points for their observations and marker-free lines for the one Engine model
evaluated at each source state. The complete interpretation, retained-input
links, and source-by-source recalculation are in
[`research-notebook.qmd`](research-notebook.qmd), with a self-contained HTML
render beside it. The fit input supplies reaction constants at 20, 40, 60, and
80 °C, so this check does not extrapolate them to the available 100 or 120 °C
observations.

The local observation snapshot is materialized from
`Canonical_VLE_Observations.csv` (SHA-256
`9e7d9ba5fead8bfa83a311dad341e3e2e8df1806d5249642a23562e99a72cb73`)
and `pco2_metrology_manifest.csv` (SHA-256
`0d14803873a60534ec5d7df382cfbd0ae03e4aaeba68bb5d54be7e4def8397cc`).

## Use the fitted parameters

Extract `mea-epcsaft-parameters.zip`, then load its single parameter document:

```python
from pathlib import Path

import epcsaft
from epcsaft import equilibrium

parameters = epcsaft.Parameters.from_json(Path("parameters.json"))
model = epcsaft.Mixture(parameters)

# Supply the application's GeneralReactiveEquilibriumProblem.
result = equilibrium.phase_equilibrium(model, problem)
```

For another simultaneous fit, reference `parameters.json` from the existing
public `regression.fit` request and supply GREPE observations in that request:

```python
from epcsaft import regression

result = regression.fit(fit_request, base_path=Path("."))
fitted = result.export_candidate_parameters()
```

The JSON contains all nine components, fixed coefficients, fitted
coefficients, binary interactions, association topology, temperature
correlations, units, validity domains, and provenance. The application's GREPE
problem still supplies its state, feed, reaction matrix, and reaction-standard-
state correlations; those are conditions, not ePC-SAFT parameters.

The campaign reads charges and source molar masses from this same JSON. Because
the reported source masses are rounded, it projects them onto the declared
reaction-conservation subspace before constructing `ChemicalEquilibriumProblem`;
no second charge or molar-mass table is stored.
